import { ModelosProcuracaoContent } from "./modelos-procuracao-content";

export default function ModelosProcuracaoPage() {
  return <ModelosProcuracaoContent />;
}
